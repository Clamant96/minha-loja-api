package br.com.helpconnect.MinhaLojaAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinhaLojaApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MinhaLojaApiApplication.class, args);
	}

}
