package br.com.helpconnect.MinhaLojaAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinhaLojaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
